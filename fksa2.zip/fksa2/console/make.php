<?php

function usage() {
    echo "Usage:\n";
    echo "php console/make.php migration create_users_table\n";
    echo "php console/make.php controller PostController\n";
    echo "php console/make.php model Post\n";
    exit;
}

if ($argc !== 3) {
    usage();
}

$type = $argv[1];
$name = $argv[2];

// Handle migration
if ($type === 'migration') {
    $timestamp = date('Y_m_d_His');
    $filename = "{$timestamp}_{$name}.php";
    $directory = __DIR__ . "/../data/migrations";

    if (!is_dir($directory)) {
        mkdir($directory, 0777, true);
    }

    $filepath = "$directory/$filename";

    $template = <<<PHP
<?php

use Core\\Schema;

require_once __DIR__ . '/../../vendor/autoload.php';

// Modify this file to define the table
Schema::create('table_name', function(\$table) {
    \$table->id();
    // \$table->string('column_name');
    \$table->timestamps();
});
PHP;

    file_put_contents($filepath, $template);
    echo "Migration file created: $filename\n";
    exit;
}

// Handle controller
if ($type === 'controller') {
    $directory = __DIR__ . '/../app/Controllers';

    if (!is_dir($directory)) {
        mkdir($directory, 0777, true);
    }

    $filepath = "$directory/{$name}.php";
    $className = basename($name);

    $template = <<<PHP
<?php
namespace Fksa\\Controllers;

use Core\\Controller;

class $className extends Controller
{
    public function index()
    {
        echo "$className loaded.";
    }
}
PHP;

    file_put_contents($filepath, $template);
    echo "Controller created: $className\n";
    exit;
}

// Handle model
if ($type === 'model') {
    $directory = __DIR__ . '/../app/Models';

    if (!is_dir($directory)) {
        mkdir($directory, 0777, true);
    }

    $filepath = "$directory/{$name}.php";
    $className = basename($name);

    $template = <<<PHP
<?php
namespace Fksa\\Models;

use PDO;

class $className
{
    protected \$pdo;

    public function __construct()
    {
        \$config = require __DIR__ . '/../../config/conn.php';
        \$dsn = "\{\$config['driver']}:host=\{\$config['host']};dbname=\{\$config['database']};port=\{\$config['port']};charset=utf8mb4";
        \$this->pdo = new PDO(\$dsn, \$config['username'], \$config['password']);
    }

    // Add your model methods here
}
PHP;

    file_put_contents($filepath, $template);
    echo "Model created: $className\n";
    exit;
}

usage();
