<?php
namespace Core;

class Table {
    public $name;
    public $columns = [];

    public function __construct($name) {
        $this->name = $name;
    }

    public function id() {
        $this->columns[] = "id INT AUTO_INCREMENT PRIMARY KEY";
    }

    public function string($name, $length = 255) {
        $this->columns[] = "$name VARCHAR($length) NOT NULL";
        return $this;
    }

    public function unique() {
        $last = array_pop($this->columns);
        $this->columns[] = str_replace('NOT NULL', 'NOT NULL UNIQUE', $last);
        return $this;
    }

    public function timestamps() {
        $this->columns[] = "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP";
    }

    public function getSQL() {
        return "CREATE TABLE {$this->name} (\n" . implode(",\n", $this->columns) . "\n);";
    }
}
