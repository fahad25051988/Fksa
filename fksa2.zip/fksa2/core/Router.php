<?php
namespace Core;

class Router {
    protected $routes = [];

    public function get($uri, $action) {
        $this->routes['GET'][$uri] = $action;
    }

    public function post($uri, $action) {
        $this->routes['POST'][$uri] = $action;
    }

    public function dispatch($uri) {
        $uri = parse_url($uri, PHP_URL_PATH);
        $method = $_SERVER['REQUEST_METHOD'];
    
        $action = $this->routes[$method][$uri] ?? null;
    
        if ($action) {
            list($controller, $methodName) = explode('@', $action);
            $controllerClass = "Fksa\\Controllers\\" . $controller;
    
            if (!class_exists($controllerClass)) {
                $this->render404();
                return;
            }
    
            $controllerInstance = new $controllerClass;
    
            if (!method_exists($controllerInstance, $methodName)) {
                $this->render404();
                return;
            }
    
            $controllerInstance->$methodName();
        } else {
            $this->render404();
        }
    }
    
    protected function render404() {
        http_response_code(404);
        $path = __DIR__ . '/../app/Views/errors/404.fksat.php';
        if (file_exists($path)) {
            require $path;
        } else {
            echo "404 Not Found";
        }
    }
    
}
