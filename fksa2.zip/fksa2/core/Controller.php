<?php
namespace Core;

class Controller {
    protected function view($viewName, $data = []) {
        $viewPath = __DIR__ . "/../app/Views/{$viewName}.fksat.php";

        if (file_exists($viewPath)) {
            extract($data);
            require $viewPath;
        } else {
            echo "View not found: {$viewName}";
        }
    }
}
