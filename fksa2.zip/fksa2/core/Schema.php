<?php
namespace Core;

use PDO;

class Schema {
    public static function create($tableName, $callback) {
        $table = new Table($tableName);
        $callback($table);

        $sql = $table->getSQL();

        $config = require __DIR__ . '/../config/conn.php';
        $dsn = "{$config['driver']}:host={$config['host']};dbname={$config['database']};port={$config['port']};charset=utf8mb4";
        $pdo = new PDO($dsn, $config['username'], $config['password']);

        $pdo->exec($sql);
        echo "  Create the table : $tableName\n";
    }
}
