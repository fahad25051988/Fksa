<?php

$router->get('/', 'HomeController@index');
$router->get('/about', 'HomeController@about');
