<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>FKSA Framework - Modern PHP Framework</title>
    <link rel="stylesheet" href="/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">
                <img src="/images/logo.png" alt="FKSA Framework Logo">
                <h1>FKSA Framework</h1>
            </div>
            <nav>
                <ul>
                    <li><a href="/docs">Documentation</a></li>
                    <li><a href="/examples">Examples</a></li>
                    <li><a href="/download" class="btn">Download</a></li>
                </ul>
            </nav>
        </header>

        <main>
            <section class="hero">
                <h2>Build Powerful Web Applications</h2>
                <p>A modern, lightweight PHP framework designed for speed and simplicity.</p>
                <div class="cta-buttons">
                    <a href="/getting-started" class="btn primary">Get Started</a>
                    <a href="/features" class="btn secondary">Explore Features</a>
                </div>
            </section>

            <section class="features">
                <div class="feature-card">
                    <h3>Lightweight</h3>
                    <p>Minimal footprint with only essential components included.</p>
                </div>
                <div class="feature-card">
                    <h3>MVC Architecture</h3>
                    <p>Clean separation of concerns following MVC pattern.</p>
                </div>
                <div class="feature-card">
                    <h3>RESTful Routing</h3>
                    <p>Intuitive routing system for building APIs and web apps.</p>
                </div>
            </section>









            <section class="commands">
    <h2 style="margin-top: 60px;">📦 FKSA Framework Commands</h2>
    <p>أوامر استخدام إطار العمل FKSA</p>

    <div class="command-group">
        <h3>🔹 Start Development Server | تشغيل السيرفر المحلي</h3>
        <pre><code id="cmd1">php -S localhost:8000 -t public</code></pre>
        <button onclick="copyToClipboard('cmd1')">📋 Copy</button>
    </div>

    <div class="command-group">
        <h3>🔹 Create Migration File | إنشاء ملف قاعدة بيانات</h3>
        <pre><code id="cmd2">php console/make.php migration create_xxxx_table</code></pre>
        <p><em>استبدل xxxx باسم الجدول</em></p>
        <button onclick="copyToClipboard('cmd2')">📋 Copy</button>
    </div>

    <div class="command-group">
        <h3>🔹 Run All Migrations | تنفيذ كل الجداول</h3>
        <pre><code id="cmd3">php console/migrate.php</code></pre>
        <button onclick="copyToClipboard('cmd3')">📋 Copy</button>
    </div>

    <div class="command-group">
        <h3>🔹 Create Controller | إنشاء كنترولر</h3>
        <pre><code id="cmd4">php console/make.php controller XxxxController</code></pre>
        <p><em>استبدل XxxxController باسم الكنترولر</em></p>
        <button onclick="copyToClipboard('cmd4')">📋 Copy</button>
    </div>

    <div class="command-group">
        <h3>🔹 Create Model | إنشاء موديل</h3>
        <pre><code id="cmd5">php console/make.php model Xxxx</code></pre>
        <p><em>استبدل Xxxx باسم الموديل</em></p>
        <button onclick="copyToClipboard('cmd5')">📋 Copy</button>
    </div>
</section>





        </main>

        <footer>
            <p>&copy; <?php echo date('Y'); ?> FKSA Framework. All rights reserved.</p>
            <p class="developer">Developed by Fahad Al-Thubiany</p>
        </footer>
    </div>
    
    <script src="/js/app.js"></script>

    
    <script>
function copyToClipboard(id) {
    const el = document.getElementById(id);
    const text = el.innerText;
    navigator.clipboard.writeText(text).then(() => {
        alert("Command copied to clipboard!");
    });
}
</script>

</body>
</html>