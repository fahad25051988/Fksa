<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="الصفحة المطلوبة غير موجودة - FKSA Framework">
    <title>404 الصفحة غير موجودة | FKSA Framework</title>
    <style>
        :root {
            --primary-bg: #2e3449;
            --secondary-bg: #12182d;
            --accent-color: #4f46e5;
            --text-color: #e5e7eb;
            --text-muted: #9ca3af;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        html {
            height: 100%;
            font-size: 62.5%;
        }
        
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, var(--primary-bg), var(--secondary-bg));
            color: var(--text-color);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            text-align: center;
            padding: 2rem;
            line-height: 1.6;
        }
        
        .container {
            max-width: 600px;
            width: 100%;
            padding: 3rem;
            background-color: rgba(18, 24, 45, 0.8);
            border-radius: 1.5rem;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .error-code {
            font-size: 8rem;
            font-weight: 800;
            background: linear-gradient(to right, var(--accent-color), #7c3aed);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-bottom: 1rem;
            line-height: 1;
        }
        
        h1 {
            font-size: 2.4rem;
            margin-bottom: 1.5rem;
            color: var(--text-color);
        }
        
        p {
            font-size: 1.6rem;
            margin-bottom: 3rem;
            color: var(--text-muted);
        }
        
        .home-btn {
            display: inline-block;
            padding: 1.2rem 2.4rem;
            background-color: var(--accent-color);
            color: white;
            text-decoration: none;
            font-size: 1.6rem;
            font-weight: 600;
            border-radius: 0.5rem;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            margin-bottom: 3rem;
        }
        
        .home-btn:hover {
            background-color: #4338ca;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(79, 70, 229, 0.3);
        }
        
        .framework-brand {
            margin-top: 3rem;
            font-size: 1.4rem;
            color: var(--text-muted);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .framework-brand span {
            color: var(--accent-color);
            font-weight: 700;
            margin-right: 0.5rem;
        }
        
        .framework-logo {
            width: 24px;
            height: 24px;
            margin-left: 0.5rem;
            fill: var(--accent-color);
        }
        
        /* Animation */
        @keyframes float {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px);
            }
        }
        
        .error-code {
            animation: float 3s ease-in-out infinite;
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .error-code {
                font-size: 6rem;
            }
            
            h1 {
                font-size: 2rem;
            }
            
            p {
                font-size: 1.4rem;
            }
            
            .container {
                padding: 2rem;
            }
        }
        
        @media (max-width: 480px) {
            .error-code {
                font-size: 5rem;
            }
            
            h1 {
                font-size: 1.8rem;
            }
            
            .home-btn {
                padding: 1rem 2rem;
                font-size: 1.4rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="error-code">404</div>
        <h1>الصفحة غير موجودة</h1>
        <p>عذراً، الصفحة التي تبحث عنها غير موجودة أو قد تم نقلها. يرجى التحقق من الرابط والمحاولة مرة أخرى.</p>
        <a href="/" class="home-btn">العودة إلى الصفحة الرئيسية</a>
        <div class="framework-brand">
            <span>FKSA</span> Framework
            <svg class="framework-logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path d="M12 2L4 12l8 10 8-10L12 2zm0 4.5L16.5 12 12 17.5 7.5 12 12 6.5z"/>
            </svg>
        </div>
    </div>
</body>
</html>