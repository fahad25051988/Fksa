<?php
namespace Fksa\Controllers;

use Core\Controller;

class HomeController extends Controller {
    public function index() {
        $this->view('index');
    }

    public function about() {
        $this->view('about'); // لو أنشأت صفحة about.fksat.php
    }
}
